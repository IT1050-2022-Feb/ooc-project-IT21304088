#ifndef STAFF
#define STAFF

#include "Person.h"
#include <iostream>
using namespace std;

class Staff : public Person {
protected:
  int staffid;
  string staff_name;
  string staff_email;

public:
  Staff();
  Staff(int sid, string sname, string sEmail);
  void setId(int sid);
  int getId();
  void setDetails(string sname, string sEmail);
  string getDetails();
  void displayDetails();
  ~Staff();
};

#endif