#include "Person.h"

Person::Person() { 
  cout << "Default Person constructor called " << endl<<endl; 
}
Person::Person(int pid, string pname, string pPass, string pemail) {
  personID = pid;
  name = pname;
  password = pPass;
  email = pemail;

  cout<<"Person Overloaded Constructor Called"<<endl;
  cout << "NAME : " << name << endl
       << "PERSON ID : " << personID << endl
       << "PASSWORD : " << password << endl
       << "EMAIL : " << email << endl;
  cout<<"Values assigned successuly"<< endl;
}
void Person::setDetails(string pname, string pPass, string pemail) {}
void Person::setId(int pid) {}
string Person::getDetails() {}
int Person::getid() {}
Person::~Person() { cout << "Person Destructor called " << endl; }