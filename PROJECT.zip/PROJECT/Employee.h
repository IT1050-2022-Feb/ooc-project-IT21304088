#include "Staff.h"
#include "Person.h"
#include <iostream>
using namespace std;

class Employee : public Staff {
private:
  int empid;
  string position;
  double salary;

public:
  Employee();
  Employee(int eid, string ePos, double eSal);
  void setDetails(int eid, string ePos, double eSal);
  void setId(int empid);
  string getId();
  string getDetails();
  void display();
  ~Employee();
};