#include "Staff.h"
#include "Person.h"
#include <iostream>
using namespace std;

class Admin : public Staff {
private:
  int adminId;
  string position;
  double salary;

public:
  Admin();
  Admin(int aid, string aPos, double aSal);
  void setDetails(int aid, string aPos, double aSal);
  void setId(int aid);
  string getId();
  string getDetails();
  void display();
  ~Admin();
};