#include "Employee.h"
#include "Person.h"
#include "Staff.h"
#include "Admin.h"

#include <iostream>
using namespace std;

int main() {

  Person pp1(875603767, "Surinimal", "@#!qRyeyu728", "qwe@gmail.com");

  Staff s1(3300, "TEAM_HYDRA", "hydra@staff.mail.com");

  Employee e1(10011, "Assisstant_Manager", 500000.00);
  
  Admin a1(91000, "Super_Admin", 1500000.00);


  return 0;
}