#include "Admin.h"
#include <iomanip>

Admin::Admin() { cout << "Default Admin constructor called " << endl << endl; }
Admin::Admin(int aid, string aPos, double aSal) {
  // Person parent class attributes
  name = "VIHAN";
  password = "ijjfsdh&#*7897";
  email = "vhn12@gmail.com";
  // Staff intermediate class attributes
  staffid = 600;
  staff_name = "MANAGEMENT";
  staff_email = "vihan@admin.mail.com";
  // Admin child class attributes
  adminId = aid;
  position = aPos;
  salary = aSal;

  cout << "Admin Overloaded Constructor Called" << endl;
  cout << "STAFF-NAME : " << staff_name << endl
       << "STAFF ID : " << staffid << endl
       << "Admin ID : " << adminId << endl
       << "POSITION : " << position << endl
       << "NAME : " << name << endl
       << "EMAIL : " << email << endl
       << "PASSWORD : " << password << endl
       << "STAFF-EMAIL : " << staff_email << endl
       << "SALARY : " << setw(8) << setprecision(2) << setiosflags(ios::fixed)
       << salary << endl
       << endl;
}
void Admin::setDetails(int eid, string ePos, double eSal) {}
void Admin::setId(int empid) {}
string Admin::getId() {}
string Admin::getDetails() {}
void Admin::display() {}
Admin::~Admin() { cout << "Admin Destructor Called" << endl << endl; }