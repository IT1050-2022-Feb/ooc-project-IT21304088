#include "Employee.h"
#include <iomanip>

Employee::Employee() {
  cout << "Default Employee constructor called " << endl << endl;
}
Employee::Employee(int eid, string ePos, double eSal) {
  // Person parent class attributes
  name = "KAMAL";
  password = "yyey#@&@(7897";
  email = "kml33@gmail.com";
  // Staff intermediate class attributes
  staffid = 5500;
  staff_name = "TEAM_ALPHA";
  staff_email = "alpha@staff.mail.com";
  // Employee child class attributes
  empid = eid;
  position = ePos;
  salary = eSal;

  cout << "Employee Overloaded Constructor Called" << endl;
  cout << "STAFF-NAME : " << staff_name << endl
       << "STAFF ID : " << staffid << endl
       << "EMPLOYEE ID : " << empid << endl
       << "POSITION : " << position << endl
       << "NAME : " << name << endl
       << "EMAIL : " << email << endl
       << "PASSWORD : " << password << endl
       << "STAFF-EMAIL : " << staff_email << endl
       << "SALARY : " << setw(8) <<setprecision(2)
       << setiosflags(ios::fixed) << salary << endl<< endl;
}
void Employee::setDetails(int eid, string ePos, double eSal) {}
void Employee::setId(int empid) {}
string Employee::getId() {}
string Employee::getDetails() {}
void Employee::display() {}
Employee::~Employee() { 
  cout << "Employee Destructor Called" << endl<<endl; 
  }