#include "Staff.h"
#include "Person.h"

Staff::Staff(){
  cout << "Default Staff Constructor called " << endl; 
}
Staff::Staff(int sid, string sname, string sEmail){

  // attributes related to parent
  name = "BENAL";
  password = "@#!Bel728";
  email = "blnl@gmail.com";
  // attributes related to child 
  staffid=sid;
  staff_name=sname;
  staff_email=sEmail;
  
  cout << "Staff Overloaded Constructor Called"<<endl;
    cout << "STAFF-NAME : " << sname << endl
         << "Staff ID : " << sid << endl
         << "NAME : " << name << endl
         << "EMAIL : " << email << endl
         << "PASSWORD : " << password << endl
         << "STAFF-EMAIL : " << sEmail << endl
         << endl;
}

void Staff::setId(int sid){}
int Staff::getId(){}
void Staff::setDetails(string sname, string sEmail){}
string Staff::getDetails(){}
void Staff::displayDetails(){}
Staff::~Staff(){
  
  cout << "Staff  destructor called " << endl; 
  
}