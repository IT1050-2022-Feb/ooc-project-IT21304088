#ifndef PERSON
#define PERSON

#include <iostream>
using namespace std;

class Person {
private:
  int personID;

protected:
  string name;
  string password;
  string email;

public:
  Person();
  Person(int pid, string pname, string pPass, string pemail);
  void setDetails(string pname, string pPass, string pemail);
  void setId(int pid);
  string getDetails();
  int getid();
  ~Person();
};

#endif 